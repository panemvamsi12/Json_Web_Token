var express = require('express');
const User = require('./model/user');
var router = express.Router();

/* Add user listing. */
router.post('/', authenticatetoken, function (req, res) {

  console.log("Inside add user service: " + JSON.stringify(req.body))

  let createUser = function () {
    return new Promise((resolve, reject) => {
      User.create({
        firstname: req.body.firstname,
        middlename: req.body.middlename,
        lastname: req.body.lastname,
        DOB: req.body.DOB,
        email: req.body.email,
        phone: req.body.phone,
        occupation: req.body.occupation,
        company: req.body.company,
        password: req.body.password
      }).then(data => {
        console.log("Add user Response from MongoDB: " + data)
        res.json(data)
        resolve(data)
      }).catch(err => {
        console.log("Error occurred while creating new user: " + err)
        resolve(null)
      })
    });
  }

  start()

  function start() {
    createUser()
  }
});

function authenticatetoken(req, res, next) {
  const bearerToken = req.headers.Authorization;
  const token = bearerToken && bearerToken.split(' ')[1]
  if (token == null) {
    console.log('Access denied>>>>>')
  }
  jwt.verify(token, 'app_secret_token', (err, user) => {
    if (err) {
      res.json({
        text: "Access denied"
      })
    } else {
      req.user = user
      res.json({
        text: 'this is authentiated',
        data: data
      })
      next()
    }
  })
}

module.exports = router;