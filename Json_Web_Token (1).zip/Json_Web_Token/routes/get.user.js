var express = require('express');
const User = require('./model/user');
var router = express.Router();

/* Get user listing. */
router.get('/', authenticatetoken, function (req, res) {

  console.log("Inside get user service: " + req.query.email);

  let getUser = function () {
    return new Promise((resolve, reject) => {
      User.findOne({
        email: req.query.email
      }).then(data => {
        console.log("Get user Response from MongoDB: " + data)
        res.json(data)
        resolve(data)
      }).catch(err => {
        console.log("Error occurred while deleting user: " + err)
        resolve(null)
      })
    });
  }

  start()

  function start() {
    deleteUser();
  }
});

function authenticatetoken(req, res, next) {
  const bearerToken = req.headers.Authorization;
  const token = bearerToken && bearerToken.split(' ')[1]
  if (token == null) {
    console.log('Access denied>>>>>')
  }
  jwt.verify(token, 'app_secret_token', (err, user) => {
    if (err) {
      res.json({
        text: "Access denied"
      })
    } else {
      req.user = user
      res.json({
        text: 'this is authentiated',
        data: data
      })
      next()
    }
  })
}

module.exports = router;