const { text } = require('express');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const userSchema = new Schema({
    firstname: { type: String, required: true },
    middlename: { type: String },
    lastname: { type: String },
    DOB: { type: String,  required: true, unique: true },
    email: { type: String, require: true, unique: true },
    phone: { type: Number, required: true },
    occupation: { type: String , required: true},
    company: { type: String, required: true },
    password: { type: String, required: true }
});
module.exports = mongoose.model('User', userSchema);